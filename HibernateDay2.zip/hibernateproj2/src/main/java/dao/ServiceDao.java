package dao;

import java.util.List;

import javax.management.relation.Role;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.hibernate.Session;
import org.hibernate.Transaction;
import model.Candidate;
import model.SessionModel;

public class ServiceDao {
	public boolean addCandidate(Candidate c){
		boolean flag = false;
		try { 
			Session session = new SessionModel().getSession();
			
			Transaction t = session.beginTransaction();
			session.save(c);
			t.commit();
			session.close();
			flag = true;
			
		}
		catch (Exception ee){
			System.out.println(ee);
		}
		
		return flag;
	}
	
	/*public List<Candidate> findAllStudentsWithCriteriaQuery() {
		Session session = new SessionModel().getSession();
		
		
	    CriteriaBuilder cb = session.getCriteriaBuilder();
	    CriteriaQuery<Candidate> cq = cb.createQuery(Candidate.class);
	    Root<Candidate> rootEntry = cq.from(Candidate.class);
	    CriteriaQuery<Candidate> all = cq.select(rootEntry);
	 
	    TypedQuery<Candidate> allQuery = session.createQuery(all);
	    return allQuery.getResultList();
	}*/
}
