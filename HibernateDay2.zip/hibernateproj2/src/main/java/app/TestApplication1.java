package app;

import model.Candidate;
import java.util.Date;
import dao.*;

public class TestApplication1 {

	@SuppressWarnings("deprecation")
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// TODO Auto-generated method stub
			Candidate candidate	= new Candidate();
				candidate.setCid(2);
				candidate.setCname("raja");
			    candidate.setDate(new java.util.Date());
				
				
				
				System.out.println(new ServiceDao().addCandidate(candidate));
				System.out.println(candidate.getCname());
	}

}
