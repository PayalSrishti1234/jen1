package model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import java.util.Date;
@Entity
@Table(name="cand")

public class Candidate {
	@Id
	private int cid;
	
private String cname;
@Column(name="dob")
@Temporal(TemporalType.DATE)
private Date date;
public int getCid() {
	return cid;
}
public void setCid(int cid) {
	this.cid = cid;
}
public String getCname() {
	return cname;
}
public void setCname(String cname) {
	this.cname = cname;
}
public Date getDate() {
	return date;
}
public void setDate(Date date) {
	this.date = date;
}
public Candidate(int cid, String cname, Date date) {
	super();
	this.cid = cid;
	this.cname = cname;
	this.date = date;
}
public Candidate() {
	super();
}

}
