package abc.hibernateproj1.app;

import abc.hibernateproj1.dao.ServiceDao;
import abc.hibernateproj1.model.Employee;

public class TestApplication3 {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Employee employee = new Employee();
		employee.setEno(102);
		
		
		
		
		System.out.println(new ServiceDao().removeEmp(employee));
		
	}
}
