package abc.hibernateproj1.app;

import abc.hibernateproj1.dao.ServiceDao;
import abc.hibernateproj1.model.Employee;
import abc.hibernateproj1.model.SessionModel;

public class TestApplication {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Employee employee = new Employee();
		employee.setEno(102);
		employee.setEname("laxman");
		employee.setSalary(9860);
		
		
		
		System.out.println(new ServiceDao().addEmp(employee));
		System.out.println(employee.getEname());
	}

}
