package abc.hibernateproj1.app;

import java.util.List;

import abc.hibernateproj1.dao.ServiceDao;
import abc.hibernateproj1.model.Employee;

public class TestApplication5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<Employee>  elist = new ServiceDao().searchAll();
		for (Employee e : elist)
		{
			System.out.printf("\n %-20s %-20s %-20s ",e.getEno(),e.getEname(),e.getSalary());
		}
	}

}
