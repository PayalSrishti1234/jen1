package abc.hibernateproj1.app;

import abc.hibernateproj1.dao.ServiceDao;
import abc.hibernateproj1.model.Employee;

public class TestApplication4 {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Employee e = new Employee();
		e.setEno(101);
		
		
		Employee emp=new ServiceDao().getEmp(e);
		if(emp!=null)
		{
			System.out.println(emp.getEname());
		}
		else{
			System.out.println("Not found");
		}
	}
}
