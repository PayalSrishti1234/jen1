package abc.hibernateproj1.app;

import abc.hibernateproj1.dao.ServiceDao;
import abc.hibernateproj1.model.Employee;

public class TestApplication2 {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Employee employee = new Employee();
		employee.setEno(102);
		employee.setEname("laxmanpart4");
		employee.setSalary(9860000);
		
		
		
		System.out.println(new ServiceDao().editEmp(employee));
		System.out.println(employee.getEname());
	}
}
