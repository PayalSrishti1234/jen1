package abc.hibernateproj1.dao;



import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import abc.hibernateproj1.model.Employee;
import abc.hibernateproj1.model.SessionModel;

public class ServiceDao {

	public boolean addEmp(Employee e){
		boolean flag = false;
		try { 
			Session session = new SessionModel().getSession();
			
			Transaction t = session.beginTransaction();
			session.save(e);
			t.commit();
			session.close();
			flag = true;
			
		}
		catch (Exception ee){
			System.out.println(ee);
		}
		
		return flag;
	}
	
	public boolean editEmp(Employee e){
		boolean flag = false;
		try { 
			Session session = new SessionModel().getSession();
			
			Transaction t = session.beginTransaction();
			session.update(e);
			t.commit();
			session.close();
			flag = true;
			
		}
		catch (Exception ee){
			System.out.println(ee);
		}
		
		return flag;
	}
	
	public boolean removeEmp(Employee e){
		boolean flag = false;
		try { 
			Session session = new SessionModel().getSession();
			
			Transaction t = session.beginTransaction();
			session.delete(e);
			t.commit();
			session.close();
			flag = true;
			
		}
		catch (Exception ee){
			System.out.println(ee);
		}
		
		return flag;
	}
	
	public Employee getEmp(Employee emp)
	{
		Employee e1 =null;
		try{
Session session = new SessionModel().getSession();
			e1=(Employee)session.get(Employee.class,emp.getEno());
			Transaction t = session.beginTransaction();
		}
		catch(Exception ee){
			System.out.println(ee);
		}
		return e1;
	}
	
	@SuppressWarnings("unchecked")
	public List<Employee> searchAll(){
		List<Employee> emplist = null;
		Session session = new SessionModel().getSession();
		Query query =session.createQuery("from Employee");
		emplist = query.list();
		return emplist;
		
	}
	
}
