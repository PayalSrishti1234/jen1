package com.jpaproj1.app;

import com.jpaproj1.dao.ServiceDao;
import com.jpaproj1.model.Places;

public class TestApplication1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Places places = new Places();
		places.setLocation("Delhi");
		places.setPlaceid(101);
		places.setPlacename("Red Fort");
		
		boolean flag = new ServiceDao().addPlace(places);
		System.out.println(flag);
	}

}
