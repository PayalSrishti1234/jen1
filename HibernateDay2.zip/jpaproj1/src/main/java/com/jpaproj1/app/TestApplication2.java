package com.jpaproj1.app;

import com.jpaproj1.dao.ServiceDao;
import com.jpaproj1.model.Places;

public class TestApplication2 {
	public static void main(String[] args) {
		
		Places place = new Places();
		place.setPlaceid(101);
		Places places = new ServiceDao().getPlace(place);
		if (places == null){
			System.out.println("not found");
		}
		else {
			System.out.println(places.getPlacename());
		}
		System.exit(0);
	}
	
}
