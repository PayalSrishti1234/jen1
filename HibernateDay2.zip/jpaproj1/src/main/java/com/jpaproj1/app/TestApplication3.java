package com.jpaproj1.app;

import java.util.Date;

import com.jpaproj1.dao.ServiceDao;
import com.jpaproj1.model.Booking;
import com.jpaproj1.model.Flight;

public class TestApplication3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Flight flight = new Flight();
		flight.setFlightid(117);
		flight.setAirline("GoAir");
		flight.setSource("Lucknow");
		flight.setDestination("Hyd");
		
		Booking b1 = new Booking();
		b1.setBookingid(1830);
		b1.setPname("abcfgggddffg");
		b1.setPage(1487);
		b1.setBookingdate(new Date());
		
		Booking b2 = new Booking();
		b2.setBookingid(1600);
		b2.setPname("defghjhugtyf");
		b2.setPage(19808);
		b2.setBookingdate(new Date());
		
		flight.getBookinglist().add(b1);
		flight.getBookinglist().add(b2);
		
		boolean flag = new ServiceDao().addFlight(flight);
		System.out.println(flag);
		System.exit(0);
	}

}
